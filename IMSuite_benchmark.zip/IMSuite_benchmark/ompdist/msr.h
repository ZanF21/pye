#ifndef _MSR_H_
#define _MSR_H_

void init_energy_measure();

double total_energy_used();

#endif // _MSR_H_
