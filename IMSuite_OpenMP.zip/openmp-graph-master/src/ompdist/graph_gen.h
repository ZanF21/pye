#ifndef _GRAPH_GEN_H_
#define _GRAPH_GEN_H_

#include "graph.h"

graph* generate_new_graph(int, int);

graph* generate_new_connected_graph(int, int);

#endif // _GRAPH_GEN_H_
