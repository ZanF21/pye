#ifndef _TREE_GEN_H_
#define _TREE_GEN_H_

#include "graph.h"
#include "graph_gen.h"

graph* generate_new_tree(int);

#endif // _TREE_GEN_H_
